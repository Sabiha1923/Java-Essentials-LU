package com.question1;

public class Main {

    public static void main(String[] args) {
        Doctor[] d = new Doctor[4];
        System.out.println("Doctors:");
        for (int i = 0; i < 4; i++)
        {
            d[i] = new Doctor();
            d[i].getDetails();
            d[i].displayDetails();
        }
        for (int i = 0; i < 4; i++) {
            d[i].getDetails();
            d[i].displayDetails();
        }
        Engineer[] e = new Engineer[4];
        System.out.println("Engineers:");
        for (int i = 0; i < 4; i++) {
            e[i] = new Engineer();
            e[i].getDetails();
            e[i].displayDetails();
        }
        for (int i = 0; i < 4; i++) {
            e[i].getDetails();
            e[i].displayDetails();
        }
        Pilot[] p = new Pilot[3];
        System.out.println("Pilots:");
        for (int i = 0; i < 3; i++) {
            p[i] = new Pilot();
            p[i].getDetails();
            p[i].displayDetails();
        }
        for (int i = 0; i < 3; i++) {
            p[i].displayDetails();
            p[i].displayDetails();
        }
    }
}
