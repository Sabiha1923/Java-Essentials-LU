package com.question1;
import java.util.Scanner;

public class Engineer extends Employee{
    Scanner sc = new Scanner(System.in);
    String compname, designation;

    public void getDetails(){
        System.out.println("Enter company name:");
        compname = sc.nextLine();

        System.out.println("Enter designation");
        designation = sc.next();
    }
    public void displayDetails(){
        System.out.println(compname+" "+designation);
    }
}
