package com.question1;

import java.util.Scanner;
import java.util.Scanner;

public class Pilot extends Employee {

    Scanner sc = new Scanner(System.in);
    String airlinename;
    String designation;

    public void getDetails(){
        System.out.println("Enter airline name:");
        airlinename = sc.nextLine();

        System.out.println("Enter designation");
        designation = sc.next();
    }
    public void displayDetails(){
        System.out.println(airlinename+" "+designation);
    }
}
