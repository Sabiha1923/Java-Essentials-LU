package com.question1;
import java.util.Scanner;

public class Employee {

        Scanner sc = new Scanner(System.in);
        String name,designation;
        int age;
        double salary;

        public void getDetails()
        {
            System.out.println("Enter employee name:");
            name= sc.next();

            System.out.println("Enter designation");
            designation = sc.nextLine();

            System.out.println("Enter your age");
            age = sc.nextInt();

            System.out.println("Enter salary");
            salary = sc.nextDouble();
        }
        public void displayDetails()
        {
            System.out.println("name: " +name+ "designation:" +designation+  "age:" +age+ " salary: "+salary);
        }

    }


//Create a parent class for different employees with common details name, age, salary,
//designation, and methods to get details and display details.

