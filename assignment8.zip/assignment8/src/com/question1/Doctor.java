package com.question1;
import java.util.Scanner;

public class Doctor extends Employee{
    Scanner sc = new Scanner(System.in);
    String hname, designation;

    public void getDetails(){
        System.out.println("Enter hospital name:");
        hname = sc.nextLine();

        System.out.println("Enter designation:");
        designation = sc.next();
    }
    public void displayDetails(){
        System.out.println(hname+" "+designation);

    }
}
