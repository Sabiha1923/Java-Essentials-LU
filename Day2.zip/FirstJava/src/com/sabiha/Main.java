package com.sabiha;

public class Main {

    public static void main(String[] args){

            {
                Employee emp1 = new Employee();
                Employee emp2 = new Employee();

                emp1.name = "Sabiha";
                emp1.age = 24;
                emp1.city = "Mumbai";
                emp1.display();
                System.out.println();

                emp2.name = "Amy";
                emp2.age = 25;
                emp2.city = "Hyderabad";
                emp2.display();
            }
        }

}
