package com.sabiha;

    class Employee {


        String name,city;
        int age;

        void display()
        {
            System.out.println("Name is: "+name);
            System.out.println("Age is: "+age);
            System.out.println("City is: "+city);
        }
    }




