package com.quizapplication;

public class Game {

    Questions [] questions= new Questions[4];
    Player player = new Player();

    String [] questionsD = {"What is the capital of India?","Who is the worldwide Handsome 2020?","What is the currency of Kuwait?","Where is river Ganges located?"};
    String[] options1={"Mumbai","Robert","Rupees","Delhi"};
    String[] options2={"Delhi","Tom Cruise","Euros","UP"};
    String[] options3={"Chennai","Kim Taehyung","Dollars","Patna"};
    String[] options4={"Nepal","Park Jimin","Dinar","Varanasi"};

    int[] answers={2,3,3,4};



    public void initGame()
    {
        for (int i = 0; i<4; i++)
        {
            questions[i] = new Questions();
        }

        questions[0].question = "What is the capital of India?";
        questions[0].option1 = "Mumbai";
        questions[0].option2 = "Delhi";
        questions[0].option3 = "Chennai";
        questions[0].option4 = "Nepal";
        questions[0].correctAns = 2;

        questions[1].question ="Who is the worldwide Handsome 2020?";
        questions[1].option1 = "Robert";
        questions[1].option2 = "Tom Cruise";
        questions[1].option3 = "Kim Taehyung";
        questions[1].option4 = "Park Jimin";
        questions[1].correctAns = 3;

        questions[2].question = "What is the currency of Kuwait?";
        questions[2].option1 = "Rupees";
        questions[2].option2 = "Euros";
        questions[2].option3 = "Dollars";
        questions[2].option4 = "Dinar";
        questions[2].correctAns = 4;

        questions[3].question ="Where is river Ganges located?";
        questions[3].option1 = "Delhi";
        questions[3].option2 = "UP";
        questions[3].option3 = "Patna";
        questions[3].option4 = "Varanasi";
        questions[3].correctAns = 4;

        for (int i=0; i<4; i++)
        {
            questions[i].question  = questionsD[i];
            questions[i].option1=options1[i];
            questions[i].option2=options2[i];
            questions[i].option3=options3[i];
            questions[i].option4=options4[i];
            questions[i].correctAns=answers[i];
        }

    }

    public void play()
    {
        player.getDetails();
        for (int i=0;i<4;i++)
        {
            boolean status =questions[1].askQuestion();
            if(status==true)
            {
                System.out.println("Well Played");
                player.score = player.score+5;
            }
            else{
                System.out.println("Ohh no. Better luck next time!");
                player.score = player.score-5;
            }

        }
        System.out.println(player.name+" your score is "+ player.score);

    }

}
