package com.Day4;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int numbers;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter elements in array");
        numbers  = sc.nextInt();

        int[] arr = new int[numbers];
        System.out.println("Enter " + numbers + " elements : ");

        for(int i=0; i<numbers; i++) {
            arr[i] = sc.nextInt();
        }

            System.out.println("Odd numbers are");
        for (int i=0; i<numbers; i++)
        {
            if(arr[i] %2 !=0)
            {
                System.out.println(arr[i] +" ");
            }
        }
    }
}
